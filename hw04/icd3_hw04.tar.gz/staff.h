/* Ian Dimayuga (icd3)
 * EECS 338 Assignment 4
 * March 28, 2012
 * staff.h
 */

#include "hw04.h"

#ifndef STAFF_H
#define STAFF_H

void staff( struct shared_info info, int arrive);

#endif //STAFF_H
