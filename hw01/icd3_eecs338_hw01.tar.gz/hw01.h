/* Ian Dimayuga (icd3)
 * EECS 338 Assignment 1
 * Febrary 6, 2012
 * hw01.h
 */

#ifndef HW01_H
#define HW01_H

#define LEN_HOST 32 //max length of hostname representation
#define LEN_BUF 32
#define ECHO_PATH "/bin/echo"
#define SLEEPYTIME 3

void childOne();
void childTwo();

#endif //HW01_H
