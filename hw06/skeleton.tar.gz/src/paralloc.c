/* 
 * Tim Henderson (tim.tadh@gmail.com)
 * EECS 338 - ParAlloc Skeleton Code
 * March 22, 2012
 * This code is placed in the public domain.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <unistd.h>

#include <stddef.h>
#include <errno.h>

#include "paralloc.h"


/*
 * void heap_init()
 *
 * Performs any initialization work on the heap. (there may be no necessary work
 * but if there is put it here.)
 */
void heap_init() {
}

/*
 * heap_ptr_t paralloc(size_t amt) 
 *    @param amt : the amount of memory to allocate
 *    @returns on success : an offset (relative to the global `heaploc` defined 
 *                          in `paralloc.h`)
 *    @return on error : -1 (and set errno to the appropriate value).
 *    
 *    Allocates the requested amount of memory from the shared memory segment.
 */
heap_ptr_t paralloc(size_t amt) { 
  errno = ENOSYS;
  return -1;
}

/*
 * int parfree(heap_ptr_t offset) 
 *
 *    @param offset : the offset pointing to the memory you want to free (as
 *                    returned by paralloc)
 *    @returns on success : 0
 *    @returns on error : -1
 *
 *    Frees the memory.
 */
int parfree(heap_ptr_t offset) {
  errno = ENOSYS;
  return -1;
}

