/**
 * A marker interface for the server.
 */
public interface Server {}
